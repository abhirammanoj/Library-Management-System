--External Documentation

--Library Management System(LMS)

Abstract:
Online Library Management System is a system which maintains the information
about the books present in the library, their authors, the members of library to
whom books are issued, library staff and all. This is very difficult to organize
manually. Maintenance of all this information manually is a very complex task.
Owing to the advancement of technology, organization of an Online Library
becomes much simple. The Online Library Management has been designed to
computerize and automate the operations performed over the information about the
members, book issues and returns and all other operations. This computerization of
library helps in many instances of its maintenances. It reduces the workload of
management as most of the manual work done is reduced.

User Type
 The homepage of the LMS application is to choose the usertype,that is whether the user is student or admin.
 The student has login which they can use after successfully registering into the LMS application.
 The registration form for students can be found in the "Sign Up" link given in the login page for students.
 The admin cannot register to the system as the admin credentials are directly entered into the database so that no illegal login is admitted.

Home
 This is the dashboard for every registered students for performing the following functionalities:
 1. Borrow Books: This allows the user to borrow books that are available in the library.This will enter the details regarding student and the borrowed book into the database.
 2. Request New Books: This allows the user to request for new books which are not available in the library and the user wish to refer the same.
 3. Search Books: This allows the user to search the required book with book name and author name as search parameters which checks whether the book is present in the library or not.
 4. View Fine: This allows the user to view the fine if the books are not returned on or before the due date.
 5. Dispaly books: This allows the user to view all the books present in the library.
 6. Update information: This allows the user to update his or her personal information.

Admin Home
 This is the dashboard for admin to perform the following functionalities:
 1. Add Books: This allows the admin to add the details of the newly arrived books in the LMS application.
 2. Book requests: This allows the admin to view the book requests which were sent by the students so that the quality of the library can be improved according to user's wish.
 3. Book Issue: This allows the admin to view the details of the students who have borrowed books from the library.
 4. Update Books: This allows the admin to update the details regarding a book in the library.
 5. Delete Books: This allows the admin to delete books that are not currently available in the library.

Other Functionalities
 Change Password: This allows both the students and admin to change their passwords.

Technology Used
 Front-end: HTML,CSS
 Back-end: PHP
 Database: Mysql

Installing and Running
 This project is host locally
 Download xampp(windows) https://www.apachefriends.org/download.html
 Extract files from the zip into C:\xampp\htdocs
 Run the apache and mysql server from xampp control panel
 Import the sql script from database folder into phpmyadmin database.
 Run localhost/foldername.
 ALTERNATIVE:
 Wamp(windows)/Lamp(Linux)
